package com.moneymoney.web.entity;

public interface TransactionType {
	public static final String WITHDRAW="Debit";
	public static final String DEPOSIT="Credit";
}
